Listing all trained hyperparameters:

Dataset: mnist
K = [1, 2, 3, 5, 10]
Step Sizes = ['1e-06', '1e-05', '0.0001', '0.001']

Dataset: cifar10
K = [1, 2, 3, 5, 10]
Step Sizes = ['1e-06', '1e-05', '0.0001', '0.001']
Do you want to run training for the missing combinations? (yes/no): 